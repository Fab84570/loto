import React from 'react';
    import { Routes, Route, Link } from 'react-router-dom';
    import DrawingPage from './DrawingPage';
    import ConfigPage from './ConfigPage';

    function App() {
      return (
        <div>
          <nav className="nav">
            <Link to="/">Configuration</Link>
            <Link to="/drawing">Tirage</Link>
          </nav>
          <Routes>
            <Route path="/" element={<ConfigPage />} />
            <Route path="/drawing" element={<DrawingPage />} />
          </Routes>
        </div>
      );
    }

    export default App;
