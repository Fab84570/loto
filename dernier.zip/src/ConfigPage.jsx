import React, { useState, useEffect } from 'react';

    function ConfigPage() {
      const [profileName, setProfileName] = useState('');
      const [gameTypes, setGameTypes] = useState(['Quine', 'Double Quine', 'Carton Plein', 'Carton Vide', 'Autre']);
      const [selectedGameType, setSelectedGameType] = useState('Quine');
      const [lotoDate, setLotoDate] = useState('');
      const [lotoLocation, setLotoLocation] = useState('');
      const [associationName, setAssociationName] = useState('');
      const [associationLogo, setAssociationLogo] = useState(null);
      const [numberOfGames, setNumberOfGames] = useState(1);
      const [gameMatrix, setGameMatrix] = useState([]);
      const [editingPartIndex, setEditingPartIndex] = useState(null);
      const [tempPartConfig, setTempPartConfig] = useState(null);
      const [showGameMatrix, setShowGameMatrix] = useState(false);

      useEffect(() => {
        loadConfig();
      }, []);

      useEffect(() => {
        saveConfig();
      }, [profileName, gameTypes, selectedGameType, lotoDate, lotoLocation, associationName, associationLogo, numberOfGames, gameMatrix, showGameMatrix]);

      const loadConfig = () => {
        try {
          const storedConfig = localStorage.getItem('lotoConfig');
          if (storedConfig) {
            const { profileName: storedProfileName, gameTypes: storedGameTypes, selectedGameType: storedSelectedGameType, lotoDate: storedLotoDate, lotoLocation: storedLotoLocation, associationName: storedAssociationName, associationLogo: storedAssociationLogo, numberOfGames: storedNumberOfGames, gameMatrix: storedGameMatrix, showGameMatrix: storedShowGameMatrix } = JSON.parse(storedConfig);
            setProfileName(storedProfileName || '');
            setGameTypes(storedGameTypes || ['Quine', 'Double Quine', 'Carton Plein', 'Carton Vide', 'Autre']);
            setSelectedGameType(storedSelectedGameType || 'Quine');
            setLotoDate(storedLotoDate || '');
            setLotoLocation(storedLotoLocation || '');
            setAssociationName(storedAssociationName || '');
            setAssociationLogo(storedAssociationLogo || null);
            setNumberOfGames(storedNumberOfGames || 1);
            setGameMatrix(storedGameMatrix || []);
            setShowGameMatrix(storedShowGameMatrix || false);
          }
        } catch (error) {
          console.error('Erreur lors du chargement de la configuration:', error);
        }
      };

      const saveConfig = () => {
        try {
          const config = { profileName, gameTypes, selectedGameType, lotoDate, lotoLocation, associationName, associationLogo, numberOfGames, gameMatrix, showGameMatrix };
          localStorage.setItem('lotoConfig', JSON.stringify(config));
        } catch (error) {
          console.error('Erreur lors de la sauvegarde de la configuration:', error);
        }
      };

      const handleProfileNameChange = (event) => {
        setProfileName(event.target.value);
      };

      const handleGameTypeChange = (event) => {
        setSelectedGameType(event.target.value);
      };

      const handleAddGameType = () => {
        const newGameType = prompt('Entrez le nouveau type de partie:');
        if (newGameType && !gameTypes.includes(newGameType)) {
          setGameTypes([...gameTypes, newGameType]);
        }
      };

      const handleLotoDateChange = (event) => {
        setLotoDate(event.target.value);
      };

      const handleLotoLocationChange = (event) => {
        setLotoLocation(event.target.value);
      };

      const handleAssociationNameChange = (event) => {
        setAssociationName(event.target.value);
      };

      const handleLogoChange = (event) => {
        const file = event.target.files[0];
        if (file) {
          const reader = new FileReader();
          reader.onloadend = () => {
            setAssociationLogo(reader.result);
          };
          reader.readAsDataURL(file);
        }
      };

      const handleNumberOfGamesChange = (event) => {
        const newNumberOfGames = parseInt(event.target.value, 10);
        setNumberOfGames(newNumberOfGames);
      };

      const handleSaveProfile = () => {
        if (!profileName) {
          alert('Veuillez entrer un nom de profil.');
          return;
        }

        const configData = {
          profileName,
          gameTypes,
          selectedGameType,
          lotoDate,
          lotoLocation,
          associationName,
          associationLogo,
          numberOfGames,
          gameMatrix,
          showGameMatrix,
        };

        const jsonString = JSON.stringify(configData, null, 2);
        const blob = new Blob([jsonString], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${profileName}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      };

      const handleLoadProfile = (event) => {
        const file = event.target.files[0];
        if (file) {
          const reader = new FileReader();
          reader.onload = (e) => {
            try {
              const config = JSON.parse(e.target.result);
              setProfileName(config.profileName || '');
              setGameTypes(config.gameTypes || ['Quine', 'Double Quine', 'Carton Plein', 'Carton Vide', 'Autre']);
              setSelectedGameType(config.selectedGameType || 'Quine');
              setLotoDate(config.lotoDate || '');
              setLotoLocation(config.lotoLocation || '');
              setAssociationName(config.associationName || '');
              setAssociationLogo(config.associationLogo || null);
              setNumberOfGames(config.numberOfGames || 1);
              setGameMatrix(config.gameMatrix || []);
              setShowGameMatrix(config.showGameMatrix || false);
            } catch (error) {
              console.error('Erreur lors du chargement du profil:', error);
              alert('Erreur lors du chargement du profil. Veuillez vérifier le format du fichier.');
            }
          };
          reader.readAsText(file);
        }
      };

      const handleGameTypeSelectChange = (partIndex, gameIndex, event) => {
        const newGameMatrix = [...gameMatrix];
        newGameMatrix[partIndex][gameIndex].type = event.target.value;
        setGameMatrix(newGameMatrix);
      };

      const handleAddGameToPart = (partIndex) => {
        const newGameMatrix = [...gameMatrix];
        newGameMatrix[partIndex].push({ type: 'Quine' });
        setGameMatrix(newGameMatrix);
      };

      const handleDuplicatePart = (partIndex) => {
        const newGameMatrix = [...gameMatrix];
        newGameMatrix.splice(partIndex + 1, 0, [...newGameMatrix[partIndex].map(game => ({ ...game }))]);
        setGameMatrix(newGameMatrix);
      };

      const handleModifyPart = (partIndex) => {
        setEditingPartIndex(partIndex);
        setTempPartConfig([...gameMatrix[partIndex]]);
      };

      const handleCancelModifyPart = () => {
        setEditingPartIndex(null);
        setTempPartConfig(null);
      };

      const handleSaveModifyPart = () => {
        const newGameMatrix = [...gameMatrix];
        newGameMatrix[editingPartIndex] = tempPartConfig;
        setGameMatrix(newGameMatrix);
        setEditingPartIndex(null);
        setTempPartConfig(null);
      };

      const handleTempGameTypeSelectChange = (gameIndex, event) => {
        const newTempPartConfig = [...tempPartConfig];
        newTempPartConfig[gameIndex].type = event.target.value;
        setTempPartConfig(newTempPartConfig);
      };

      const handleAddTempGameToPart = () => {
        const newTempPartConfig = [...tempPartConfig];
        newTempPartConfig.push({ type: 'Quine' });
        setTempPartConfig(newTempPartConfig);
      };

      const handleConfigureParts = () => {
        if (numberOfGames > 0) {
          const initialMatrix = Array(numberOfGames).fill([{ type: 'Quine' }]);
          setGameMatrix(initialMatrix);
          setShowGameMatrix(true);
        }
      };

      const renderGameMatrix = () => {
        return (
          <div className="game-matrix">
            {gameMatrix.map((part, partIndex) => (
              <div key={partIndex} className="game-matrix-part">
                <h4>Partie {partIndex + 1}</h4>
                {editingPartIndex === partIndex ? (
                  <div>
                    {tempPartConfig.map((game, gameIndex) => (
                      <div key={gameIndex}>
                        <select value={game.type} onChange={(event) => handleTempGameTypeSelectChange(gameIndex, event)}>
                          {gameTypes.map((type) => (
                            <option key={type} value={type}>
                              {type}
                            </option>
                          ))}
                        </select>
                      </div>
                    ))}
                    <button type="button" onClick={handleAddTempGameToPart}>
                      Ajouter un jeu
                    </button>
                    <button type="button" onClick={handleSaveModifyPart}>
                      Enregistrer
                    </button>
                    <button type="button" onClick={handleCancelModifyPart}>
                      Annuler
                    </button>
                  </div>
                ) : (
                  <div>
                    {part.map((game, gameIndex) => (
                      <div key={gameIndex}>
                        <select value={game.type} onChange={(event) => handleGameTypeSelectChange(partIndex, gameIndex, event)} disabled>
                          {gameTypes.map((type) => (
                            <option key={type} value={type}>
                              {type}
                            </option>
                          ))}
                        </select>
                      </div>
                    ))}
                    <button type="button" onClick={() => handleAddGameToPart(partIndex)} disabled>
                      Ajouter un jeu
                    </button>
                    <button type="button" onClick={() => handleModifyPart(partIndex)}>
                      Modifier
                    </button>
                    <button type="button" onClick={() => handleDuplicatePart(partIndex)}>
                      Dupliquer
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        );
      };

      const renderGameMatrixDetails = () => {
        return (
          <div>
            <h3>Configuration détaillée des parties:</h3>
            <ul>
              {gameMatrix.map((part, partIndex) => (
                <li key={partIndex}>
                  <strong>Partie {partIndex + 1}:</strong>{' '}
                  {part.map((game, gameIndex) => (
                    <span key={gameIndex}>
                      {game.type}
                      {gameIndex < part.length - 1 ? ', ' : ''}
                    </span>
                  ))}
                </li>
              ))}
            </ul>
          </div>
        );
      };

      return (
        <form className="config-form">
          <h2>Configuration du Loto</h2>

          <label htmlFor="profileName">Nom du profil:</label>
          <input type="text" id="profileName" value={profileName} onChange={handleProfileNameChange} />

          <label htmlFor="gameType">Type de partie:</label>
          <select id="gameType" value={selectedGameType} onChange={handleGameTypeChange}>
            {gameTypes.map((type) => (
              <option key={type} value={type}>
                {type}
              </option>
            ))}
          </select>
          <button type="button" onClick={handleAddGameType}>
            Ajouter un type de partie
          </button>

          <label htmlFor="lotoDate">Date du loto:</label>
          <input type="date" id="lotoDate" value={lotoDate} onChange={handleLotoDateChange} />

          <label htmlFor="lotoLocation">Lieu du loto:</label>
          <input type="text" id="lotoLocation" value={lotoLocation} onChange={handleLotoLocationChange} />

          <label htmlFor="associationName">Nom de l'association:</label>
          <input type="text" id="associationName" value={associationName} onChange={handleAssociationNameChange} />

          <label htmlFor="associationLogo">Logo de l'association:</label>
          <input type="file" id="associationLogo" accept="image/*" onChange={handleLogoChange} />
          {associationLogo && <img src={associationLogo} alt="Logo de l'association" style={{ maxWidth: '100px', marginTop: '10px' }} />}

          <label htmlFor="numberOfGames">Nombre de parties:</label>
          <input type="number" id="numberOfGames" value={numberOfGames} onChange={handleNumberOfGamesChange} min="1" />

          {!showGameMatrix && (
            <button type="button" onClick={handleConfigureParts}>
              Configurer les parties
            </button>
          )}

          {showGameMatrix && renderGameMatrix()}
          {showGameMatrix && renderGameMatrixDetails()}

          <button type="button" onClick={handleSaveProfile}>
            Enregistrer le profil
          </button>

          <label htmlFor="loadProfile">Charger le profil:</label>
          <input type="file" id="loadProfile" accept=".json" onChange={handleLoadProfile} />
        </form>
      );
    }

    export default ConfigPage;
