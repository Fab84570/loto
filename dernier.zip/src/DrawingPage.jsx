import React, { useState, useEffect } from 'react';

    function DrawingPage() {
      const [selectedNumbers, setSelectedNumbers] = useState([]);
      const [lastNumber, setLastNumber] = useState(null);
      const [gameType, setGameType] = useState('Quine');
      const [history, setHistory] = useState([]);
      const [currentPart, setCurrentPart] = useState(0);
      const [partData, setPartData] = useState({});
      const [gameMatrix, setGameMatrix] = useState([[{ type: 'Quine' }]]);
      const [currentGameIndex, setCurrentGameIndex] = useState(0);

      useEffect(() => {
        loadConfig();
        loadState();
      }, []);

      useEffect(() => {
        saveState();
      }, [selectedNumbers, lastNumber, gameType, history, currentPart, partData, currentGameIndex]);

      const loadConfig = () => {
        try {
          const storedConfig = localStorage.getItem('lotoConfig');
          if (storedConfig) {
            const { gameMatrix: storedGameMatrix } = JSON.parse(storedConfig);
            setGameMatrix(storedGameMatrix || [[{ type: 'Quine' }]]);
          }
        } catch (error) {
          console.error('Erreur lors du chargement de la configuration:', error);
        }
      };

      const loadState = () => {
        try {
          const storedState = localStorage.getItem('lotoState');
          if (storedState) {
            const { partData: storedPartData, currentPart: storedCurrentPart, currentGameIndex: storedCurrentGameIndex } = JSON.parse(storedState);
            setPartData(storedPartData || {});
            setCurrentPart(storedCurrentPart || 0);
            setCurrentGameIndex(storedCurrentGameIndex || 0);
            if (storedPartData && storedPartData[storedCurrentPart]) {
              setSelectedNumbers(storedPartData[storedCurrentPart].selectedNumbers || []);
              setLastNumber(storedPartData[storedCurrentPart].lastNumber || null);
              setHistory(storedPartData[storedCurrentPart].history || []);
            }
          }
        } catch (error) {
          console.error('Erreur lors du chargement de l\'état:', error);
        }
      };

      const saveState = () => {
        try {
          const state = {
            partData: {
              ...partData,
              [currentPart]: { selectedNumbers, lastNumber, history },
            },
            currentPart,
            currentGameIndex,
          };
          localStorage.setItem('lotoState', JSON.stringify(state));
        } catch (error) {
          console.error('Erreur lors de la sauvegarde de l\'état:', error);
        }
      };

      useEffect(() => {
        if (partData[currentPart]) {
          setSelectedNumbers(partData[currentPart].selectedNumbers || []);
          setLastNumber(partData[currentPart].lastNumber || null);
          setHistory(partData[currentPart].history || []);
        } else {
          setSelectedNumbers([]);
          setLastNumber(null);
          setHistory([]);
        }
        setGameType(gameMatrix[currentPart] && gameMatrix[currentPart][currentGameIndex] ? gameMatrix[currentPart][currentGameIndex].type : 'Quine');
      }, [currentPart, partData, gameMatrix, currentGameIndex]);

      const handleNumberClick = (number) => {
        const isSelected = selectedNumbers.includes(number);
        let newSelectedNumbers;

        if (isSelected) {
          newSelectedNumbers = selectedNumbers.filter((num) => num !== number);
        } else {
          newSelectedNumbers = [...selectedNumbers, number];
        }

        setSelectedNumbers(newSelectedNumbers);
        setLastNumber(number);
        setHistory([...history, { number, selected: !isSelected }]);
      };

      const handleUndo = () => {
        if (history.length > 0) {
          const lastAction = history[history.length - 1];
          const newHistory = history.slice(0, -1);
          setHistory(newHistory);

          if (lastAction.selected) {
            setSelectedNumbers(selectedNumbers.filter(num => num !== lastAction.number));
          } else {
            setSelectedNumbers([...selectedNumbers, lastAction.number]);
          }

          setLastNumber(newHistory.length > 0 ? newHistory[newHistory.length - 1].number : null);
        }
      };

      const handleClear = () => {
        setSelectedNumbers([]);
        setLastNumber(null);
        setHistory([]);
      };

      const handleNextPart = () => {
        if (currentPart < gameMatrix.length - 1) {
          setCurrentPart(currentPart + 1);
          setCurrentGameIndex(0);
        }
      };

      const handlePreviousPart = () => {
        if (currentPart > 0) {
          setCurrentPart(currentPart - 1);
          setCurrentGameIndex(0);
        }
      };

      const handleNextGame = () => {
        if (gameMatrix[currentPart] && currentGameIndex < gameMatrix[currentPart].length - 1) {
          setCurrentGameIndex(currentGameIndex + 1);
        }
      };

      const handlePreviousGame = () => {
        if (currentGameIndex > 0) {
          setCurrentGameIndex(currentGameIndex - 1);
        }
      };

      const renderNumberGrid = () => {
        const numbers = Array.from({ length: 90 }, (_, i) => i + 1);
        return (
          <div className="grid">
            {numbers.map((number) => (
              <div
                key={number}
                className={`number-cell ${selectedNumbers.includes(number) ? 'selected' : ''}`}
                onClick={() => handleNumberClick(number)}
              >
                {number}
              </div>
            ))}
          </div>
        );
      };

      return (
        <div className="container">
          <div>
            <div className="game-type-select">
              <label htmlFor="gameType">
                Partie {currentPart + 1} - Jeu {currentGameIndex + 1} / {gameMatrix[currentPart] ? gameMatrix[currentPart].length : 0} - Type: {gameType}
              </label>
            </div>
            <div className="controls">
              <button onClick={handlePreviousPart} disabled={currentPart === 0}>
                Partie précédente
              </button>
              <button onClick={handlePreviousGame} disabled={currentGameIndex === 0}>
                Jeu précédent
              </button>
              <button onClick={handleUndo}>Numéro précédent</button>
              <button onClick={handleClear}>Effacer</button>
              <button onClick={handleNextGame} disabled={!gameMatrix[currentPart] || currentGameIndex === gameMatrix[currentPart].length - 1}>
                Jeu suivant
              </button>
              <button onClick={handleNextPart} disabled={currentPart === gameMatrix.length - 1}>
                Partie suivante
              </button>
            </div>
            {renderNumberGrid()}
          </div>
          <div className="selected-number-display">
            <h2>Dernier numéro :</h2>
            <div className="number">{lastNumber}</div>
          </div>
        </div>
      );
    }

    export default DrawingPage;
